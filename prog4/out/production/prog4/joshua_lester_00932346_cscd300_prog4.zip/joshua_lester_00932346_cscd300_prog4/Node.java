/**
 * Author: Joshua Lester
 * CSCD300
 * Programming Assignment 4
 */

public class Node {
    private int element;
    private Node next;

    public Node(int element, Node next) {
        this.element = element;
        this.next = next;
    }

    // Getters
    public int getElement() {
        return this.element;
    }

    public Node getNext() {
        return this.next;
    }

    // Setters
    public void setElement(int element) {
        this.element = element;
    }

    public void setNext(Node next) {
        this.next = next;
    }
}
